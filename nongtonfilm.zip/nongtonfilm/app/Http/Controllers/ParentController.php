<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//optional
use Illuminate\Support\Facades\DB;

class ParentController extends Controller
{
    //About me
    public function Index()
    {
        $data_film = \App\Datafilm::all();
        return view('templatefilm.index', ['data_film' => $data_film]);
    }

    public function AboutMe()
    {
        return view('templatefilm.about');
    }

    public function MoreReviews()
    {
        $data_film = \App\Datafilm::all();
        return view('templatefilm.more_reviews', ['data_film' => $data_film]);
    }

    public function ContactMe()
    {
        return view('templatefilm._contactme');
    }

    // public function FilmList()
    // {
    //     // mengambil data dari table pegawai
    //     $film = DB::table('film')->get();
    //     // dd($film);

    //     // mengirim data pegawai ke view index
    //     return view('more_reviews', ['film' => $film]);
    // }
}

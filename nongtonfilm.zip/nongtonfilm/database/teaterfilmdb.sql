-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2019 at 02:39 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `teaterfilmdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `film`
--

CREATE TABLE `film` (
  `id_film` char(5) NOT NULL,
  `judul_film` varchar(50) NOT NULL,
  `genre` varchar(30) NOT NULL,
  `albums_genre` text NOT NULL,
  `durasi` char(10) NOT NULL,
  `produser` varchar(15) NOT NULL,
  `foto` text NOT NULL,
  `href` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `film`
--

INSERT INTO `film` (`id_film`, `judul_film`, `genre`, `albums_genre`, `durasi`, `produser`, `foto`, `href`) VALUES
('BC404', 'THE END', 'ACTION', 'Action._CB1513316166_SX233_CR0,0,233,131_AL_.jpg', '146 Menit', 'GREGOR PRODUCTI', 'films.jpg', 'https://www.youtube.com/watch?v=jwepltujbXw&t=9s'),
('BF404', 'WHO I AM I ?', 'CRIMINAL ACTION', 'Crime._CB1513316167_SX233_CR0,0,233,131_AL_.jpg', '130 Menit', 'RAY PICTURES', 'films.jpg', 'https://www.youtube.com/watch?v=jwepltujbXw&t=9s'),
('BN404', 'THE SUN', 'ROMANTIC', 'Romance._CB1513316168_SX233_CR0,0,233,131_AL_.jpg', '200 Menit', 'BRAY PICTURES', 'films.jpg', 'https://www.youtube.com/watch?v=jwepltujbXw&t=9s'),
('CL404', 'COMIC 8 CASINO KINGS', 'COMEDY', 'Comedy._CB1513316167_SX233_CR0,0,233,131_AL_.jpg', '120 Menit', 'BAMBANG ', 'films.jpg', 'https://www.youtube.com/watch?v=xqjFBAtuT8A'),
('FL404', 'JAMES BOND', 'ACTION', 'Action._CB1513316166_SX233_CR0,0,233,131_AL_.jpg', '120 Menit', 'THOMAS ADULT', 'films.jpg', 'https://www.youtube.com/watch?v=RjeleKfs7Rg'),
('KL404', 'KING KONG', 'ADVENTURE', 'Adventure._CB1513316166_SX233_CR0,0,233,131_AL_.jpg', '160 Menit', 'ALBERTON', 'films.jpg', 'https://www.youtube.com/watch?v=jwepltujbXw&t=9s'),
('SL404', 'SERIGALA TERAKHIR', 'CRIME & GANGSTER', 'Crime._CB1513316167_SX233_CR0,0,233,131_AL_.jpg', '170 Menit', 'SUGENG', 'films.jpg', 'https://www.youtube.com/watch?v=jwepltujbXw&t=9s'),
('TL404', 'THE FAULT IN OUR', 'DRAMA', 'Drama._CB1513316168_SX233_CR0,0,233,131_AL_.jpg', '140 Menit', 'JACKSON', 'films.jpg', 'https://www.youtube.com/watch?v=jwepltujbXw&t=9s');

-- --------------------------------------------------------

--
-- Table structure for table `hari`
--

CREATE TABLE `hari` (
  `id_hari` char(5) NOT NULL,
  `jml_tiket` varchar(50) NOT NULL,
  `htmsenin_kamis` int(11) NOT NULL,
  `htmjumat_minggu` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hari`
--

INSERT INTO `hari` (`id_hari`, `jml_tiket`, `htmsenin_kamis`, `htmjumat_minggu`) VALUES
('HR1', '10', 35000, 45000),
('HR2', '5', 35000, 45000),
('HR3', '8', 35000, 45000),
('HR4', '7', 35000, 45000),
('HR5', '6', 35000, 45000);

-- --------------------------------------------------------

--
-- Table structure for table `jadwal`
--

CREATE TABLE `jadwal` (
  `id_jadwal` char(5) NOT NULL,
  `tgl_tayang` date NOT NULL,
  `jam_tayang` time NOT NULL,
  `id_film` char(5) NOT NULL,
  `id_teater` char(5) NOT NULL,
  `id_operator` char(5) NOT NULL,
  `id_hari` char(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jadwal`
--

INSERT INTO `jadwal` (`id_jadwal`, `tgl_tayang`, `jam_tayang`, `id_film`, `id_teater`, `id_operator`, `id_hari`) VALUES
('TAY01', '2019-10-24', '19:22:07', 'CL404', 'TH101', 'OP001', 'HR1'),
('TAY02', '2019-10-26', '22:00:00', 'FL404', 'TH102', 'OP002', 'HR2'),
('TAY03', '2019-10-27', '20:10:00', 'KL404', 'TH104', 'OP003', 'HR5');

-- --------------------------------------------------------

--
-- Table structure for table `kursi`
--

CREATE TABLE `kursi` (
  `no_seat` int(11) NOT NULL,
  `baris` char(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kursi`
--

INSERT INTO `kursi` (`no_seat`, `baris`) VALUES
(1, 'SEAT1'),
(2, 'SEAT2'),
(3, 'SEAT3'),
(4, 'SEAT4'),
(5, 'SEAT5');

-- --------------------------------------------------------

--
-- Table structure for table `operator`
--

CREATE TABLE `operator` (
  `id_operator` char(5) NOT NULL,
  `nama_operator` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `operator`
--

INSERT INTO `operator` (`id_operator`, `nama_operator`) VALUES
('OP001', 'Bagus'),
('OP002', 'Ajeng'),
('OP003', 'Ratna');

-- --------------------------------------------------------

--
-- Table structure for table `teater`
--

CREATE TABLE `teater` (
  `id_teater` char(5) NOT NULL,
  `nama_teater` char(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teater`
--

INSERT INTO `teater` (`id_teater`, `nama_teater`) VALUES
('TH101', 'ROOM TEATER 1'),
('TH102', 'ROOM TEATER 2'),
('TH103', 'ROOM TEATER 3'),
('TH104', 'ROOM TEATER 4'),
('TH105', 'ROOM TEATER 5');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `no_trx` int(11) NOT NULL,
  `id_jadwal` char(5) NOT NULL,
  `no_seat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `film`
--
ALTER TABLE `film`
  ADD PRIMARY KEY (`id_film`);

--
-- Indexes for table `hari`
--
ALTER TABLE `hari`
  ADD PRIMARY KEY (`id_hari`);

--
-- Indexes for table `jadwal`
--
ALTER TABLE `jadwal`
  ADD PRIMARY KEY (`id_jadwal`),
  ADD KEY `id_film` (`id_film`),
  ADD KEY `id_teater` (`id_teater`),
  ADD KEY `id_operator` (`id_operator`),
  ADD KEY `id_hari` (`id_hari`);

--
-- Indexes for table `kursi`
--
ALTER TABLE `kursi`
  ADD PRIMARY KEY (`no_seat`);

--
-- Indexes for table `operator`
--
ALTER TABLE `operator`
  ADD PRIMARY KEY (`id_operator`);

--
-- Indexes for table `teater`
--
ALTER TABLE `teater`
  ADD PRIMARY KEY (`id_teater`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD KEY `id_jadwal` (`id_jadwal`),
  ADD KEY `no_seat` (`no_seat`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `jadwal`
--
ALTER TABLE `jadwal`
  ADD CONSTRAINT `jadwal_ibfk_1` FOREIGN KEY (`id_film`) REFERENCES `film` (`id_film`),
  ADD CONSTRAINT `jadwal_ibfk_2` FOREIGN KEY (`id_teater`) REFERENCES `teater` (`id_teater`),
  ADD CONSTRAINT `jadwal_ibfk_3` FOREIGN KEY (`id_operator`) REFERENCES `operator` (`id_operator`),
  ADD CONSTRAINT `jadwal_ibfk_4` FOREIGN KEY (`id_hari`) REFERENCES `hari` (`id_hari`);

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`id_jadwal`) REFERENCES `jadwal` (`id_jadwal`),
  ADD CONSTRAINT `transaksi_ibfk_2` FOREIGN KEY (`no_seat`) REFERENCES `kursi` (`no_seat`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

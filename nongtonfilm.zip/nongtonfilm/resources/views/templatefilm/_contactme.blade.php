<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1">

    <title>Movie Review | Contact</title>

    <!-- Loading third party fonts -->
    <link href="http://fonts.googleapis.com/css?family=Roboto:300,400,700|" rel="stylesheet" type="text/css">
    <link href="fonts/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- Loading main css file -->
    <link rel="stylesheet" href="assets/style.css">

    <!--[if lt IE 9]>
		<script src="js/ie-support/html5.js"></script>
		<script src="js/ie-support/respond.js"></script>
		<![endif]-->

</head>


<body>


    <div id="site-content">
        @include('templatefilm._header')
        <main class="main-content">
            <div class="container">
                <div class="page">
                    <div class="breadcrumbs">
                        <a href="/">Home</a>
                        <span>Kontak Kami</span>
                    </div>

                    <div class="content">
                        <div class="row">
                            <div class="col-md-4">
                                <h2>Contact</h2>
                                <ul class="contact-detail">
                                    <li>
                                        <img src="assets/images/icon-contact-map.png" alt="#">
                                        <address><span>CINEMAKU. INC</span> <br>Kembangan, Jakarta Barat</address>
                                    </li>
                                    <li>
                                        <img src="assets/images/icon-contact-phone.png" alt="">
                                        <a href="tel:082177321451">+62821-7732-1451</a>
                                    </li>
                                    <li>
                                        <img src="assets/images/icon-contact-message.png" alt="">
                                        <a href="mailto:jioashter19@gmail.com">jioashter19@gmail.com</a>
                                    </li>
                                </ul>
                                <!-- <div class="contact-form">
                                    <input type="text" class="name" placeholder="name...">
                                    <input type="text" class="email" placeholder="email...">
                                    <input type="text" class="website" placeholder="website...">
                                    <textarea class="message" placeholder="message..."></textarea>
                                    <input type="submit" value="Send Message ">

                                </div> -->
                            </div>
                            <div class="col-md-7 col-md-offset-1">
                                <div class="map"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- .container -->
        </main>
        @include('templatefilm._footer')
    </div>
    <!-- Default snippet for navigation -->
    @include('templatefilm._jscompact')

</body>

</html>
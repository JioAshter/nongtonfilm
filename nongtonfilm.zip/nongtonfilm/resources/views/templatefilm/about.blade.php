<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1">

    <title>About Me</title>

    <!-- Loading third party fonts -->
    <link href="http://fonts.googleapis.com/css?family=Roboto:300,400,700|" rel="stylesheet" type="text/css">
    <link href="assets/fonts/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- Loading main css file -->
    <link rel="stylesheet" href="assets/style.css">

    <!--[if lt IE 9]>
		<script src="js/ie-support/html5.js"></script>
		<script src="js/ie-support/respond.js"></script>
		<![endif]-->

</head>


<body>


    <div id="site-content">
        @include('templatefilm._header')
        <main class="main-content">
            <div class="container">
                <div class="page">
                    <div class="breadcrumbs">
                        <a href="index.html">Home</a>
                        <span>About me</span>
                    </div>

                    <div class="row">
                        <div class="col-md-4">
                            <figure><img src="assets/dummy/figure.jpg" alt="figure image"></figure>
                        </div>
                        <div class="col-md-8">
                            <p class="leading">Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptas commodi aspernatur iure ex harum libero corrupti autem magnam in beatae? Modi pariatur vitae debitis nobis qui doloremque ea, aspernatur similique?</p>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione consectetur id, nulla ipsa libero repellendus, et voluptatibus quidem veniam totam velit. Est, fugiat quaerat iure maxime nihil possimus excepturi dicta?</p>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-9">
                            <h2 class="section-title">Vision &amp; Misssion</h2>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ad cupiditate quia voluptatibus ab hic nostrum dolor saepe excepturi! Repudiandae deserunt fugiat laborum asperiores harum animi optio, magnam delectus beatae pariatur.</p>

                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum commodi, in eaque velit dolorem aliquid? Voluptatem veritatis, culpa ab mollitia cum odio veniam atque laboriosam! Sed totam quasi in magnam.</p>
                        </div>
                        <div class="col-md-3">
                            <h2 class="section-title">Useful Links</h2>
                            <ul class="arrow">
                                <li><a href="#">Eiusmod tempor incididunt</a></li>
                                <li><a href="#">Tenim ad minim venia</a></li>
                                <li><a href="#">Quis nostrud exercitation</a></li>
                                <li><a href="#">Ullamco laboris reprehenderit</a></li>
                                <li><a href="#">Duis aute dolor voluptat</a></li>
                                <li><a href="#">Velit esse cillum dolore</a></li>
                                <li><a href="#">Excepteur sint occaeca</a></li>
                            </ul>
                        </div>
                    </div> <!-- .row -->

                    <h2 class="section-title">Our Team</h2>
                    <div class="row">

                        <div class="col-md-3">
                            <div class="team">
                                <figure class="team-image"><img src="assets/images/users.png" alt=""></figure>
                                <h2 class="team-name">Sarah Stuart</h2>
                                <small class="team-title">Co-founder</small>
                                <div class="social-links">
                                    <a href="" class="facebook"><i class="fa fa-facebook"></i></a>
                                    <a href="" class="twitter"><i class="fa fa-twitter"></i></a>
                                    <a href="" class="google-plus"><i class="fa fa-google-plus"></i></a>
                                    <a href="" class="pinterest"><i class="fa fa-pinterest"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="team">
                                <figure class="team-image"><img src="assets/images/users_2.png" alt=""></figure>
                                <h2 class="team-name">John Doe</h2>
                                <small class="team-title">Managing Director</small>
                                <div class="social-links">
                                    <a href="" class="facebook"><i class="fa fa-facebook"></i></a>
                                    <a href="" class="twitter"><i class="fa fa-twitter"></i></a>
                                    <a href="" class="google-plus"><i class="fa fa-google-plus"></i></a>
                                    <a href="" class="pinterest"><i class="fa fa-pinterest"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="team">
                                <figure class="team-image"><img src="assets/images/users_3.png" alt=""></figure>
                                <h2 class="team-name">Jessica Branson</h2>
                                <small class="team-title">Reviewer</small>
                                <div class="social-links">
                                    <a href="" class="facebook"><i class="fa fa-facebook"></i></a>
                                    <a href="" class="twitter"><i class="fa fa-twitter"></i></a>
                                    <a href="" class="google-plus"><i class="fa fa-google-plus"></i></a>
                                    <a href="" class="pinterest"><i class="fa fa-pinterest"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="team">
                                <figure class="team-image"><img src="assets/images/users_4.png" alt=""></figure>
                                <h2 class="team-name">Sarah Stuart</h2>
                                <small class="team-title">Consultant</small>
                                <div class="social-links">
                                    <a href="" class="facebook"><i class="fa fa-facebook"></i></a>
                                    <a href="" class="twitter"><i class="fa fa-twitter"></i></a>
                                    <a href="" class="google-plus"><i class="fa fa-google-plus"></i></a>
                                    <a href="" class="pinterest"><i class="fa fa-pinterest"></i></a>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div> <!-- .container -->
        </main>
        @include('templatefilm._footer')
    </div>
    <!-- Default snippet for navigation -->
    @include('templatefilm._jscompact')

</body>

</html>
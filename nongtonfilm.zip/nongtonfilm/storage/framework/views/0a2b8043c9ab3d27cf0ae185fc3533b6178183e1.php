<script src="assets/js/jquery-1.11.1.min.js"></script>
<script src="assets/js/plugins.js"></script>
<script src="assets/js/app.js"></script>
<script src="http://maps.google.com/maps/api/js?sensor=false&amp;language=en"></script><?php /**PATH C:\xampp\htdocs\nongtonfilm\resources\views/templatefilm/_jscompact.blade.php ENDPATH**/ ?>